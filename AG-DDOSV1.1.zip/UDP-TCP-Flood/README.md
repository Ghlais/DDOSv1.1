# UDP TCP Flood
Attack DDOS Samp v4.9 **( Update Last Now )**
# Setup & Use  
  วิธีใช้งาน
  
  1). py udp-flood.py ( สำหรับยิงเซิร์ฟเวอร์ )
  
  2). py tcp-flood.py ( สำหรับยิงเครื่อง )
  
# Credits & Developer 
**SIRISAKz | Connecting_Z**

หากมีปัญหาขัดข้องกรุณาติดต่อ **Facebook : Sirisak Sangsinchai**
