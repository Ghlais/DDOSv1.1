### Table of contents

* [EAS Phish](https://github.com/pembriahmad/EAS-Phish)
* [Get Linux](https://github.com/pembriahmad/Get-Linux)
* [DDOS Attack](https://github.com/pembriahmad/DDOS)
* [Bash Crypt](https://github.com/pembriahmad/Bash-Crypt)

# DDOS-Attack Tools

A simple device to attack a website or server, for a complete understanding of ddos that you can click the link below
https://en.m.wikipedia.org/wiki/Denial-of-service_attack#Distributed_DoS

# How to Install
* ```pkg install python```
* ```pkg install python2```
* ```pkg install git```
* ```git clone https://github.com/pembriahmad/DDOS```
* ```cd DDOS```

Type command ```python2 ddos.py``` To run the script

# Sources
 * Github https://github.com/pembriahmad
 * Gitlab Project https://gitlab.com/pembriahmad/resources


# Screenshot

![](https://raw.githubusercontent.com/pembriahmad/DDOS/master/Screenshot.jpg)
