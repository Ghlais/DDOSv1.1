# ddos-attack
One of the best ddos 2021 tools made by me
This script was paid, but I left it for you to use for free, I hope you do not forget the support.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Installation for termux: 

apt update

apt upgrade

pkg install git

pkg install python

pkg install python2

pip install requests 

git clone https://github.com/noobhackers008/ddos-attack

pip install -r requirements.txt

cd ddos-attack

python3 ddos-attack.py

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Installation for linux :

sudo apt install git

sudo apt install python

pip3 install requests

git clone https://github.com/noobhackers008/ddos-attack

pip3 install -r requirements.txt

cd ddos-attack

python3 ddos-attack.py

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

donations : 

If you like this tool and it was useful for you, give us help and energy

bitcoin cash (btc) = bc1qxfrdfjs42wamrs2lupeda3lek8uq9eqvr354lv

thanks a lot :)




